#install.packages('plyr')
#install.packages('stringr')
#install.packages('shiny')
#install.packages('ggplot2')
#install.packages('showtext')
rm(list=ls())
library(plyr)
library(stringr)
library(shiny)
library(ggplot2)
Sys.setlocale(category = "LC_CTYPE", locale = "ko_KR.UTF-8")

require(showtext) #R샤이니에서 한글 안깨지게 하는 코드
font_add_google(name='Nanum Gothic', regular.wt=400,bold.wt=700)
showtext_auto()
showtext_opts(dpi=112)

setwd("/Users/welcomeonboardboy/Documents/gamsung") #불러들일경로 (negative,positive.txt여기에있어야함)
#txt<-readLines("15.txt",warn=FALSE) #감정분석할 텍스트파일 불러오기

path <- file.path("/Users/welcomeonboardboy/Documents/gamsung")  # 폴더 경로를 객체로 만든다
kor <- list.files(file.path(path, "스스로 행복하라"))  #폴더 경로 중 eng라는 폴더에 있는 파일들 이름을 list-up해서 객체로 만든다.
kor.files <- file.path(path, "스스로 행복하라", kor)   #아까 list-up한 파일의 이름들로 폴더의 경로를 다시 객체로 만든다.
#all.files <- c(kor.files, eng.files) 다른 폴더에 있는 파일과 같이 돌릴때 사용
txt <- lapply(kor.files, readLines)    #txt에 이름을 붙여서 새 객체 생성월
topic <- setNames(txt, kor.files)      # 텍스트 파일의 목록만큼 데이터를 읽어오고, 그 결과를 list 형태로 저장
topic <- sapply(topic, function(x) paste(x, collapse = " "))  #topic에 있는 리스트들을 공백을 두고 이어붙임

positive <- readLines("positive.txt")
positive=positive[-1]
negative <- readLines("negative.txt")
negative=negative[-1]

sentimental = function(sentences, positive, negative){
  
  scores = laply(sentences, function(sentence, positive, negative) {
    
    sentence = gsub('[[:punct:]]', '', sentence) # 문장부호 제거
    sentence = gsub('[[:cntrl:]]', '', sentence) # 특수문자 제거
    sentence = gsub('\\d+', '', sentence)        # 숫자 제거
    
    word.list = str_split(sentence, '\\s+')      # 공백 기준으로 단어 생성 -> \\s+ : 공백 정규식, +(1개 이상)
    words = unlist(word.list)                    # unlist() : list를 vector 객체로 구조변경
    
    pos.matches = match(words, positive)           # words의 단어를 positive에서 matching
    neg.matches = match(words, negative)
    
    pos.matches = !is.na(pos.matches)            # NA 제거, 위치(숫자)만 추출
    neg.matches = !is.na(neg.matches)
    
    score = sum(pos.matches) - sum(neg.matches)  # 긍정 - 부정   
    return(score)
  }, positive, negative)
  
  scores.df = data.frame(score=scores, text=sentences)
  return(scores.df)
}

result=sentimental(topic, positive, negative)

result$color[result$score >=1] = "Olive Drab 2"
result$color[result$score ==0] = "Gray 60"
result$color[result$score < 0] = "Orange Red 2"

result$remark[result$score >=1] = "긍정"
result$remark[result$score ==0] = "중립"
result$remark[result$score < 0] = "부정"

sentiment_result= table(result$remark)
pie(sentiment_result, main="감성분석 결과",col=c("Olive Drab 2","Orange Red 2","Gray 60"), radius=0.8) #결과 파이그래프로 나타냄 
sentiment_result #결과 숫자로 확인

ui <- fluidPage( #r샤이니를 이용하여 웹으로 결과 나타내는 부분
  headerPanel("감정분석 결과"),
  mainPanel(plotOutput(outputId = "sentiment_result"))
)

server <- function(input,output){
  output$sentiment_result <- renderPlot({pie(sentiment_result, main="감성분석 결과",col=c("Olive Drab 2","Orange Red 2","Gray 60"), radius=0.8)})
}
shinyApp(ui=ui,server=server)

#print(score)
#txt